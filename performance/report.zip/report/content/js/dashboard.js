/*
   Licensed to the Apache Software Foundation (ASF) under one or more
   contributor license agreements.  See the NOTICE file distributed with
   this work for additional information regarding copyright ownership.
   The ASF licenses this file to You under the Apache License, Version 2.0
   (the "License"); you may not use this file except in compliance with
   the License.  You may obtain a copy of the License at

       http://www.apache.org/licenses/LICENSE-2.0

   Unless required by applicable law or agreed to in writing, software
   distributed under the License is distributed on an "AS IS" BASIS,
   WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
   See the License for the specific language governing permissions and
   limitations under the License.
*/
var showControllersOnly = false;
var seriesFilter = "";
var filtersOnlySampleSeries = true;

/*
 * Add header in statistics table to group metrics by category
 * format
 *
 */
function summaryTableHeader(header) {
    var newRow = header.insertRow(-1);
    newRow.className = "tablesorter-no-sort";
    var cell = document.createElement('th');
    cell.setAttribute("data-sorter", false);
    cell.colSpan = 1;
    cell.innerHTML = "Requests";
    newRow.appendChild(cell);

    cell = document.createElement('th');
    cell.setAttribute("data-sorter", false);
    cell.colSpan = 3;
    cell.innerHTML = "Executions";
    newRow.appendChild(cell);

    cell = document.createElement('th');
    cell.setAttribute("data-sorter", false);
    cell.colSpan = 7;
    cell.innerHTML = "Response Times (ms)";
    newRow.appendChild(cell);

    cell = document.createElement('th');
    cell.setAttribute("data-sorter", false);
    cell.colSpan = 1;
    cell.innerHTML = "Throughput";
    newRow.appendChild(cell);

    cell = document.createElement('th');
    cell.setAttribute("data-sorter", false);
    cell.colSpan = 2;
    cell.innerHTML = "Network (KB/sec)";
    newRow.appendChild(cell);
}

/*
 * Populates the table identified by id parameter with the specified data and
 * format
 *
 */
function createTable(table, info, formatter, defaultSorts, seriesIndex, headerCreator) {
    var tableRef = table[0];

    // Create header and populate it with data.titles array
    var header = tableRef.createTHead();

    // Call callback is available
    if(headerCreator) {
        headerCreator(header);
    }

    var newRow = header.insertRow(-1);
    for (var index = 0; index < info.titles.length; index++) {
        var cell = document.createElement('th');
        cell.innerHTML = info.titles[index];
        newRow.appendChild(cell);
    }

    var tBody;

    // Create overall body if defined
    if(info.overall){
        tBody = document.createElement('tbody');
        tBody.className = "tablesorter-no-sort";
        tableRef.appendChild(tBody);
        var newRow = tBody.insertRow(-1);
        var data = info.overall.data;
        for(var index=0;index < data.length; index++){
            var cell = newRow.insertCell(-1);
            cell.innerHTML = formatter ? formatter(index, data[index]): data[index];
        }
    }

    // Create regular body
    tBody = document.createElement('tbody');
    tableRef.appendChild(tBody);

    var regexp;
    if(seriesFilter) {
        regexp = new RegExp(seriesFilter, 'i');
    }
    // Populate body with data.items array
    for(var index=0; index < info.items.length; index++){
        var item = info.items[index];
        if((!regexp || filtersOnlySampleSeries && !info.supportsControllersDiscrimination || regexp.test(item.data[seriesIndex]))
                &&
                (!showControllersOnly || !info.supportsControllersDiscrimination || item.isController)){
            if(item.data.length > 0) {
                var newRow = tBody.insertRow(-1);
                for(var col=0; col < item.data.length; col++){
                    var cell = newRow.insertCell(-1);
                    cell.innerHTML = formatter ? formatter(col, item.data[col]) : item.data[col];
                }
            }
        }
    }

    // Add support of columns sort
    table.tablesorter({sortList : defaultSorts});
}

$(document).ready(function() {

    // Customize table sorter default options
    $.extend( $.tablesorter.defaults, {
        theme: 'blue',
        cssInfoBlock: "tablesorter-no-sort",
        widthFixed: true,
        widgets: ['zebra']
    });

    var data = {"OkPercent": 80.03050894466787, "KoPercent": 19.96949105533213};
    var dataset = [
        {
            "label" : "FAIL",
            "data" : data.KoPercent,
            "color" : "#FF6347"
        },
        {
            "label" : "PASS",
            "data" : data.OkPercent,
            "color" : "#9ACD32"
        }];
    $.plot($("#flot-requests-summary"), dataset, {
        series : {
            pie : {
                show : true,
                radius : 1,
                label : {
                    show : true,
                    radius : 3 / 4,
                    formatter : function(label, series) {
                        return '<div style="font-size:8pt;text-align:center;padding:2px;color:white;">'
                            + label
                            + '<br/>'
                            + Math.round10(series.percent, -2)
                            + '%</div>';
                    },
                    background : {
                        opacity : 0.5,
                        color : '#000'
                    }
                }
            }
        },
        legend : {
            show : true
        }
    });

    // Creates APDEX table
    createTable($("#apdexTable"), {"supportsControllersDiscrimination": true, "overall": {"data": [0.3827485785605325, 500, 1500, "Total"], "isController": false}, "titles": ["Apdex", "T (Toleration threshold)", "F (Frustration threshold)", "Label"], "items": [{"data": [0.625, 500, 1500, "Get Settings Page"], "isController": false}, {"data": [0.49723145071982283, 500, 1500, "Post Login Page"], "isController": false}, {"data": [0.5, 500, 1500, "Get Post Page"], "isController": false}, {"data": [0.5, 500, 1500, "Post Like Post"], "isController": false}, {"data": [0.49611973392461195, 500, 1500, "Get Dashboard Page"], "isController": false}, {"data": [0.07070135746606335, 500, 1500, "Delete Post"], "isController": false}, {"data": [0.4816414686825054, 500, 1500, "Get Host Page"], "isController": false}, {"data": [0.5033222591362126, 500, 1500, "Get Login Page"], "isController": false}, {"data": [0.5005592841163311, 500, 1500, "Get Create Post Page"], "isController": false}, {"data": [0.25, 500, 1500, "Post Bio Settings"], "isController": false}, {"data": [0.5, 500, 1500, "Post Save Post"], "isController": false}, {"data": [0.0, 500, 1500, "Post Create Post Page"], "isController": false}, {"data": [0.5, 500, 1500, "Get Post Page-1"], "isController": false}, {"data": [1.0, 500, 1500, "Get Post Page-0"], "isController": false}]}, function(index, item){
        switch(index){
            case 0:
                item = item.toFixed(3);
                break;
            case 1:
            case 2:
                item = formatDuration(item);
                break;
        }
        return item;
    }, [[0, 0]], 3);

    // Create statistics table
    createTable($("#statisticsTable"), {"supportsControllersDiscrimination": true, "overall": {"data": ["Total", 7211, 1440, 19.96949105533213, 1022.2118984884183, 104, 6733, 934.0, 1435.0, 1599.3999999999996, 3491.76, 1.9151974677217118, 41.854165830460936, 10.394594103414157], "isController": false}, "titles": ["Label", "#Samples", "FAIL", "Error %", "Average", "Min", "Max", "Median", "90th pct", "95th pct", "99th pct", "Transactions/s", "Received", "Sent"], "items": [{"data": ["Get Settings Page", 4, 0, 0.0, 811.5, 420, 1749, 538.5, 1749.0, 1749.0, 1749.0, 0.0020346531959060743, 0.007215667071223544, 0.012046974928494658], "isController": false}, {"data": ["Post Login Page", 903, 0, 0.0, 975.6212624584716, 751, 1645, 947.0, 1138.4, 1227.8, 1439.4800000000005, 0.23997767649520976, 6.72834991678515, 1.3134245921475745], "isController": false}, {"data": ["Get Post Page", 888, 0, 0.0, 743.8738738738741, 542, 1395, 715.0, 907.1, 962.6499999999999, 1091.66, 0.2364789561691048, 6.5922706458711655, 1.28835847661548], "isController": false}, {"data": ["Post Like Post", 4, 0, 0.0, 687.5, 673, 709, 684.0, 709.0, 709.0, 709.0, 0.0020347411707493748, 0.060562362082700015, 0.01092083737738141], "isController": false}, {"data": ["Get Dashboard Page", 902, 0, 0.0, 977.8403547671838, 769, 2354, 943.0, 1150.7, 1242.85, 1485.6100000000004, 0.23984150252458442, 8.26354867464636, 1.3076857493664276], "isController": false}, {"data": ["Delete Post", 884, 720, 81.44796380090497, 1152.7952488687786, 843, 2038, 1109.0, 1422.0, 1499.0, 1663.5499999999993, 0.2354067143640437, 0.9769809298591847, 1.351717505767997], "isController": false}, {"data": ["Get Host Page", 926, 0, 0.0, 1079.5550755939503, 759, 3015, 1023.0, 1275.0, 1423.65, 2310.880000000001, 0.24593993275694148, 6.772998234697078, 1.2207465044691483], "isController": false}, {"data": ["Get Login Page", 903, 0, 0.0, 705.2535991140652, 204, 1148, 685.0, 849.2, 922.5999999999997, 1053.88, 0.2400442127945426, 6.171780962746095, 1.2598725721275708], "isController": false}, {"data": ["Get Create Post Page", 894, 0, 0.0, 692.5011185682337, 425, 1160, 673.0, 823.0, 877.75, 1031.05, 0.2377244821116316, 6.121988393198554, 1.2914481895745051], "isController": false}, {"data": ["Post Bio Settings", 4, 0, 0.0, 1529.0, 1331, 1658, 1563.5, 1658.0, 1658.0, 1658.0, 0.0020350879692213296, 0.02301944841357261, 0.012633842012050773], "isController": false}, {"data": ["Post Save Post", 4, 0, 0.0, 684.75, 646, 765, 664.0, 765.0, 765.0, 765.0, 0.0020347473810257773, 0.060562546926361475, 0.010920870709099289], "isController": false}, {"data": ["Post Create Post Page", 893, 720, 80.62709966405374, 1855.8477043673008, 1117, 6733, 1495.0, 3371.4000000000005, 3676.0999999999995, 4192.179999999995, 0.23764340768405187, 0.18728888523420115, 1.3487940657374091], "isController": false}, {"data": ["Get Post Page-1", 1, 0, 0.0, 706.0, 706, 706, 706.0, 706.0, 706.0, 706.0, 1.41643059490085, 36.410842333569406, 7.668643767705383], "isController": false}, {"data": ["Get Post Page-0", 1, 0, 0.0, 104.0, 104, 104, 104.0, 104.0, 104.0, 104.0, 9.615384615384617, 1.6995943509615385, 52.490234375], "isController": false}]}, function(index, item){
        switch(index){
            // Errors pct
            case 3:
                item = item.toFixed(2) + '%';
                break;
            // Mean
            case 4:
            // Mean
            case 7:
            // Median
            case 8:
            // Percentile 1
            case 9:
            // Percentile 2
            case 10:
            // Percentile 3
            case 11:
            // Throughput
            case 12:
            // Kbytes/s
            case 13:
            // Sent Kbytes/s
                item = item.toFixed(2);
                break;
        }
        return item;
    }, [[0, 0]], 0, summaryTableHeader);

    // Create error table
    createTable($("#errorsTable"), {"supportsControllersDiscrimination": false, "titles": ["Type of error", "Number of errors", "% in errors", "% in all samples"], "items": [{"data": ["500/Internal Server Error", 1440, 100.0, 19.96949105533213], "isController": false}]}, function(index, item){
        switch(index){
            case 2:
            case 3:
                item = item.toFixed(2) + '%';
                break;
        }
        return item;
    }, [[1, 1]]);

        // Create top5 errors by sampler
    createTable($("#top5ErrorsBySamplerTable"), {"supportsControllersDiscrimination": false, "overall": {"data": ["Total", 7211, 1440, "500/Internal Server Error", 1440, "", "", "", "", "", "", "", ""], "isController": false}, "titles": ["Sample", "#Samples", "#Errors", "Error", "#Errors", "Error", "#Errors", "Error", "#Errors", "Error", "#Errors", "Error", "#Errors"], "items": [{"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": ["Delete Post", 884, 720, "500/Internal Server Error", 720, "", "", "", "", "", "", "", ""], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": ["Post Create Post Page", 893, 720, "500/Internal Server Error", 720, "", "", "", "", "", "", "", ""], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}]}, function(index, item){
        return item;
    }, [[0, 0]], 0);

});
