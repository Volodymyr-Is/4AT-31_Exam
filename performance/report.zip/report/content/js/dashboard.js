/*
   Licensed to the Apache Software Foundation (ASF) under one or more
   contributor license agreements.  See the NOTICE file distributed with
   this work for additional information regarding copyright ownership.
   The ASF licenses this file to You under the Apache License, Version 2.0
   (the "License"); you may not use this file except in compliance with
   the License.  You may obtain a copy of the License at

       http://www.apache.org/licenses/LICENSE-2.0

   Unless required by applicable law or agreed to in writing, software
   distributed under the License is distributed on an "AS IS" BASIS,
   WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
   See the License for the specific language governing permissions and
   limitations under the License.
*/
var showControllersOnly = false;
var seriesFilter = "";
var filtersOnlySampleSeries = true;

/*
 * Add header in statistics table to group metrics by category
 * format
 *
 */
function summaryTableHeader(header) {
    var newRow = header.insertRow(-1);
    newRow.className = "tablesorter-no-sort";
    var cell = document.createElement('th');
    cell.setAttribute("data-sorter", false);
    cell.colSpan = 1;
    cell.innerHTML = "Requests";
    newRow.appendChild(cell);

    cell = document.createElement('th');
    cell.setAttribute("data-sorter", false);
    cell.colSpan = 3;
    cell.innerHTML = "Executions";
    newRow.appendChild(cell);

    cell = document.createElement('th');
    cell.setAttribute("data-sorter", false);
    cell.colSpan = 7;
    cell.innerHTML = "Response Times (ms)";
    newRow.appendChild(cell);

    cell = document.createElement('th');
    cell.setAttribute("data-sorter", false);
    cell.colSpan = 1;
    cell.innerHTML = "Throughput";
    newRow.appendChild(cell);

    cell = document.createElement('th');
    cell.setAttribute("data-sorter", false);
    cell.colSpan = 2;
    cell.innerHTML = "Network (KB/sec)";
    newRow.appendChild(cell);
}

/*
 * Populates the table identified by id parameter with the specified data and
 * format
 *
 */
function createTable(table, info, formatter, defaultSorts, seriesIndex, headerCreator) {
    var tableRef = table[0];

    // Create header and populate it with data.titles array
    var header = tableRef.createTHead();

    // Call callback is available
    if(headerCreator) {
        headerCreator(header);
    }

    var newRow = header.insertRow(-1);
    for (var index = 0; index < info.titles.length; index++) {
        var cell = document.createElement('th');
        cell.innerHTML = info.titles[index];
        newRow.appendChild(cell);
    }

    var tBody;

    // Create overall body if defined
    if(info.overall){
        tBody = document.createElement('tbody');
        tBody.className = "tablesorter-no-sort";
        tableRef.appendChild(tBody);
        var newRow = tBody.insertRow(-1);
        var data = info.overall.data;
        for(var index=0;index < data.length; index++){
            var cell = newRow.insertCell(-1);
            cell.innerHTML = formatter ? formatter(index, data[index]): data[index];
        }
    }

    // Create regular body
    tBody = document.createElement('tbody');
    tableRef.appendChild(tBody);

    var regexp;
    if(seriesFilter) {
        regexp = new RegExp(seriesFilter, 'i');
    }
    // Populate body with data.items array
    for(var index=0; index < info.items.length; index++){
        var item = info.items[index];
        if((!regexp || filtersOnlySampleSeries && !info.supportsControllersDiscrimination || regexp.test(item.data[seriesIndex]))
                &&
                (!showControllersOnly || !info.supportsControllersDiscrimination || item.isController)){
            if(item.data.length > 0) {
                var newRow = tBody.insertRow(-1);
                for(var col=0; col < item.data.length; col++){
                    var cell = newRow.insertCell(-1);
                    cell.innerHTML = formatter ? formatter(col, item.data[col]) : item.data[col];
                }
            }
        }
    }

    // Add support of columns sort
    table.tablesorter({sortList : defaultSorts});
}

$(document).ready(function() {

    // Customize table sorter default options
    $.extend( $.tablesorter.defaults, {
        theme: 'blue',
        cssInfoBlock: "tablesorter-no-sort",
        widthFixed: true,
        widgets: ['zebra']
    });

    var data = {"OkPercent": 82.23405542781072, "KoPercent": 17.765944572189277};
    var dataset = [
        {
            "label" : "FAIL",
            "data" : data.KoPercent,
            "color" : "#FF6347"
        },
        {
            "label" : "PASS",
            "data" : data.OkPercent,
            "color" : "#9ACD32"
        }];
    $.plot($("#flot-requests-summary"), dataset, {
        series : {
            pie : {
                show : true,
                radius : 1,
                label : {
                    show : true,
                    radius : 3 / 4,
                    formatter : function(label, series) {
                        return '<div style="font-size:8pt;text-align:center;padding:2px;color:white;">'
                            + label
                            + '<br/>'
                            + Math.round10(series.percent, -2)
                            + '%</div>';
                    },
                    background : {
                        opacity : 0.5,
                        color : '#000'
                    }
                }
            }
        },
        legend : {
            show : true
        }
    });

    // Creates APDEX table
    createTable($("#apdexTable"), {"supportsControllersDiscrimination": true, "overall": {"data": [0.35737625559724073, 500, 1500, "Total"], "isController": false}, "titles": ["Apdex", "T (Toleration threshold)", "F (Frustration threshold)", "Label"], "items": [{"data": [0.1346153846153846, 500, 1500, "Get Settings Page"], "isController": false}, {"data": [0.0, 500, 1500, "Get Settings Page-1"], "isController": false}, {"data": [0.1125, 500, 1500, "Get Dashboard Page-1"], "isController": false}, {"data": [1.0, 500, 1500, "Get Settings Page-0"], "isController": false}, {"data": [1.0, 500, 1500, "Get Dashboard Page-0"], "isController": false}, {"data": [0.4280983916745506, 500, 1500, "Post Login Page"], "isController": false}, {"data": [0.4844420600858369, 500, 1500, "Get Post Page"], "isController": false}, {"data": [0.6153846153846154, 500, 1500, "Post Like Post"], "isController": false}, {"data": [0.4491106719367589, 500, 1500, "Get Dashboard Page"], "isController": false}, {"data": [0.07836644591611479, 500, 1500, "Delete Post"], "isController": false}, {"data": [0.4106813996316759, 500, 1500, "Get Host Page"], "isController": false}, {"data": [0.43226716839134527, 500, 1500, "Get Login Page"], "isController": false}, {"data": [0.46770833333333334, 500, 1500, "Get Create Post Page"], "isController": false}, {"data": [0.0, 500, 1500, "Get Create Post Page-1"], "isController": false}, {"data": [0.40384615384615385, 500, 1500, "Post Bio Settings"], "isController": false}, {"data": [1.0, 500, 1500, "Get Create Post Page-0"], "isController": false}, {"data": [0.6538461538461539, 500, 1500, "Post Save Post"], "isController": false}, {"data": [0.026068821689259645, 500, 1500, "Post Create Post Page"], "isController": false}, {"data": [0.027777777777777776, 500, 1500, "Get Post Page-1"], "isController": false}, {"data": [1.0, 500, 1500, "Get Post Page-0"], "isController": false}]}, function(index, item){
        switch(index){
            case 0:
                item = item.toFixed(3);
                break;
            case 1:
            case 2:
                item = formatDuration(item);
                break;
        }
        return item;
    }, [[0, 0]], 3);

    // Create statistics table
    createTable($("#statisticsTable"), {"supportsControllersDiscrimination": true, "overall": {"data": ["Total", 8263, 1468, 17.765944572189277, 1240.074791238044, 6, 6733, 958.0, 2462.800000000001, 3662.7999999999993, 4759.36, 0.04851266783002349, 1.0475955106137649, 0.23959661882006705], "isController": false}, "titles": ["Label", "#Samples", "FAIL", "Error %", "Average", "Min", "Max", "Median", "90th pct", "95th pct", "99th pct", "Transactions/s", "Received", "Sent"], "items": [{"data": ["Get Settings Page", 26, 0, 0.0, 2735.307692307692, 309, 4199, 2853.5, 4183.0, 4195.85, 4199.0, 1.542777527059947E-4, 5.706376192711664E-4, 6.817797202665457E-4], "isController": false}, {"data": ["Get Settings Page-1", 9, 0, 0.0, 3898.2222222222217, 3529, 4131, 3946.0, 4131.0, 4131.0, 4131.0, 0.01061413378054217, 0.04042492357823678, 0.008406311031269237], "isController": false}, {"data": ["Get Dashboard Page-1", 40, 0, 0.0, 1881.75, 778, 2822, 1880.5, 2651.2, 2729.35, 2822.0, 0.047310963132931975, 1.200608093723018, 0.017371994275373462], "isController": false}, {"data": ["Get Settings Page-0", 9, 0, 0.0, 86.33333333333333, 28, 137, 88.0, 137.0, 137.0, 137.0, 0.010662066971996674, 0.0018846036346986308, 0.008694165939079318], "isController": false}, {"data": ["Get Dashboard Page-0", 40, 0, 0.0, 27.35, 6, 109, 21.5, 62.79999999999998, 72.79999999999998, 109.0, 0.0474410307987172, 0.00838557282672638, 0.01760507002296146], "isController": false}, {"data": ["Post Login Page", 1057, 0, 0.0, 1332.5288552507118, 751, 5329, 972.0, 2572.6000000000013, 4267.999999999999, 4875.380000000003, 0.0062058069996489, 0.16529028375218804, 0.02947301361196209], "isController": false}, {"data": ["Get Post Page", 932, 0, 0.0, 801.0515021459235, 542, 4560, 720.0, 942.5000000000002, 1050.199999999999, 3002.4699999999943, 0.005472114389830741, 0.152427342377389, 0.02929991211385037], "isController": false}, {"data": ["Post Like Post", 26, 0, 0.0, 664.5384615384615, 6, 1634, 684.0, 1576.6, 1621.75, 1634.0, 1.542765150314249E-4, 0.002917624790579273, 5.523335659467157E-4], "isController": false}, {"data": ["Get Dashboard Page", 1012, 0, 0.0, 1211.8458498023722, 769, 5009, 960.0, 1550.8000000000002, 3595.849999999997, 4769.360000000001, 0.005941674712684507, 0.20269948103184932, 0.0312913554063809], "isController": false}, {"data": ["Delete Post", 906, 727, 80.24282560706402, 1150.135761589403, 15, 2207, 1109.5, 1431.8000000000004, 1527.65, 1722.5099999999998, 0.005319459712693163, 0.022382544830510005, 0.030307275164727258], "isController": false}, {"data": ["Get Host Page", 1086, 0, 0.0, 1490.1786372007377, 759, 6593, 1052.5, 3072.4000000000005, 4383.849999999993, 5558.679999999996, 0.006375984178071586, 0.1749863602888652, 0.027091562873036906], "isController": false}, {"data": ["Get Login Page", 1063, 0, 0.0, 1074.9435559736617, 124, 4531, 704.0, 2843.0, 3602.3999999999996, 4304.8799999999965, 0.006241075057176584, 0.16016158177449322, 0.028089189547599556], "isController": false}, {"data": ["Get Create Post Page", 960, 0, 0.0, 863.5250000000001, 425, 4345, 682.0, 916.8, 2747.499999999999, 3972.12, 0.005636373850156249, 0.14512165043659117, 0.02992460182702941], "isController": false}, {"data": ["Get Create Post Page-1", 25, 0, 0.0, 3689.4800000000005, 2817, 4042, 3758.0, 3934.2000000000003, 4016.5, 4042.0, 0.0294650097116672, 0.7477321702806483, 0.009812078429373549], "isController": false}, {"data": ["Post Bio Settings", 26, 0, 0.0, 2165.3076923076924, 55, 6411, 1655.0, 6296.2, 6388.95, 6411.0, 1.5427681895558925E-4, 0.0011497632911482163, 6.837747488573651E-4], "isController": false}, {"data": ["Get Create Post Page-0", 25, 0, 0.0, 97.04000000000002, 26, 181, 86.0, 169.4, 178.6, 181.0, 0.02959455460195324, 0.005231068733353063, 0.010404335602249187], "isController": false}, {"data": ["Post Save Post", 26, 0, 0.0, 620.4615384615385, 9, 1506, 692.5, 1278.7, 1433.5499999999997, 1506.0, 1.542765232703172E-4, 0.0029176249463903916, 5.523335954432127E-4], "isController": false}, {"data": ["Post Create Post Page", 959, 741, 77.2679874869656, 1906.5912408759118, 23, 6733, 1502.0, 3549.0, 3922.0, 5170.599999999999, 0.0056306004144662065, 0.004408854570289661, 0.03121350462527403], "isController": false}, {"data": ["Get Post Page-1", 18, 0, 0.0, 1994.1666666666667, 706, 3364, 1843.5, 3124.6000000000004, 3364.0, 3364.0, 0.0017331419687838024, 0.04401355026357238, 8.802051849926851E-4], "isController": false}, {"data": ["Get Post Page-0", 18, 0, 0.0, 69.49999999999999, 23, 229, 56.0, 133.60000000000014, 229.0, 229.0, 0.0017332561199829215, 3.063665602704188E-4, 9.261523180182181E-4], "isController": false}]}, function(index, item){
        switch(index){
            // Errors pct
            case 3:
                item = item.toFixed(2) + '%';
                break;
            // Mean
            case 4:
            // Mean
            case 7:
            // Median
            case 8:
            // Percentile 1
            case 9:
            // Percentile 2
            case 10:
            // Percentile 3
            case 11:
            // Throughput
            case 12:
            // Kbytes/s
            case 13:
            // Sent Kbytes/s
                item = item.toFixed(2);
                break;
        }
        return item;
    }, [[0, 0]], 0, summaryTableHeader);

    // Create error table
    createTable($("#errorsTable"), {"supportsControllersDiscrimination": false, "titles": ["Type of error", "Number of errors", "% in errors", "% in all samples"], "items": [{"data": ["500/Internal Server Error", 1468, 100.0, 17.765944572189277], "isController": false}]}, function(index, item){
        switch(index){
            case 2:
            case 3:
                item = item.toFixed(2) + '%';
                break;
        }
        return item;
    }, [[1, 1]]);

        // Create top5 errors by sampler
    createTable($("#top5ErrorsBySamplerTable"), {"supportsControllersDiscrimination": false, "overall": {"data": ["Total", 8263, 1468, "500/Internal Server Error", 1468, "", "", "", "", "", "", "", ""], "isController": false}, "titles": ["Sample", "#Samples", "#Errors", "Error", "#Errors", "Error", "#Errors", "Error", "#Errors", "Error", "#Errors", "Error", "#Errors"], "items": [{"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": ["Delete Post", 906, 727, "500/Internal Server Error", 727, "", "", "", "", "", "", "", ""], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": ["Post Create Post Page", 959, 741, "500/Internal Server Error", 741, "", "", "", "", "", "", "", ""], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}]}, function(index, item){
        return item;
    }, [[0, 0]], 0);

});
