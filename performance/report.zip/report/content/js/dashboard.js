/*
   Licensed to the Apache Software Foundation (ASF) under one or more
   contributor license agreements.  See the NOTICE file distributed with
   this work for additional information regarding copyright ownership.
   The ASF licenses this file to You under the Apache License, Version 2.0
   (the "License"); you may not use this file except in compliance with
   the License.  You may obtain a copy of the License at

       http://www.apache.org/licenses/LICENSE-2.0

   Unless required by applicable law or agreed to in writing, software
   distributed under the License is distributed on an "AS IS" BASIS,
   WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
   See the License for the specific language governing permissions and
   limitations under the License.
*/
var showControllersOnly = false;
var seriesFilter = "";
var filtersOnlySampleSeries = true;

/*
 * Add header in statistics table to group metrics by category
 * format
 *
 */
function summaryTableHeader(header) {
    var newRow = header.insertRow(-1);
    newRow.className = "tablesorter-no-sort";
    var cell = document.createElement('th');
    cell.setAttribute("data-sorter", false);
    cell.colSpan = 1;
    cell.innerHTML = "Requests";
    newRow.appendChild(cell);

    cell = document.createElement('th');
    cell.setAttribute("data-sorter", false);
    cell.colSpan = 3;
    cell.innerHTML = "Executions";
    newRow.appendChild(cell);

    cell = document.createElement('th');
    cell.setAttribute("data-sorter", false);
    cell.colSpan = 7;
    cell.innerHTML = "Response Times (ms)";
    newRow.appendChild(cell);

    cell = document.createElement('th');
    cell.setAttribute("data-sorter", false);
    cell.colSpan = 1;
    cell.innerHTML = "Throughput";
    newRow.appendChild(cell);

    cell = document.createElement('th');
    cell.setAttribute("data-sorter", false);
    cell.colSpan = 2;
    cell.innerHTML = "Network (KB/sec)";
    newRow.appendChild(cell);
}

/*
 * Populates the table identified by id parameter with the specified data and
 * format
 *
 */
function createTable(table, info, formatter, defaultSorts, seriesIndex, headerCreator) {
    var tableRef = table[0];

    // Create header and populate it with data.titles array
    var header = tableRef.createTHead();

    // Call callback is available
    if(headerCreator) {
        headerCreator(header);
    }

    var newRow = header.insertRow(-1);
    for (var index = 0; index < info.titles.length; index++) {
        var cell = document.createElement('th');
        cell.innerHTML = info.titles[index];
        newRow.appendChild(cell);
    }

    var tBody;

    // Create overall body if defined
    if(info.overall){
        tBody = document.createElement('tbody');
        tBody.className = "tablesorter-no-sort";
        tableRef.appendChild(tBody);
        var newRow = tBody.insertRow(-1);
        var data = info.overall.data;
        for(var index=0;index < data.length; index++){
            var cell = newRow.insertCell(-1);
            cell.innerHTML = formatter ? formatter(index, data[index]): data[index];
        }
    }

    // Create regular body
    tBody = document.createElement('tbody');
    tableRef.appendChild(tBody);

    var regexp;
    if(seriesFilter) {
        regexp = new RegExp(seriesFilter, 'i');
    }
    // Populate body with data.items array
    for(var index=0; index < info.items.length; index++){
        var item = info.items[index];
        if((!regexp || filtersOnlySampleSeries && !info.supportsControllersDiscrimination || regexp.test(item.data[seriesIndex]))
                &&
                (!showControllersOnly || !info.supportsControllersDiscrimination || item.isController)){
            if(item.data.length > 0) {
                var newRow = tBody.insertRow(-1);
                for(var col=0; col < item.data.length; col++){
                    var cell = newRow.insertCell(-1);
                    cell.innerHTML = formatter ? formatter(col, item.data[col]) : item.data[col];
                }
            }
        }
    }

    // Add support of columns sort
    table.tablesorter({sortList : defaultSorts});
}

$(document).ready(function() {

    // Customize table sorter default options
    $.extend( $.tablesorter.defaults, {
        theme: 'blue',
        cssInfoBlock: "tablesorter-no-sort",
        widthFixed: true,
        widgets: ['zebra']
    });

    var data = {"OkPercent": 99.36708860759494, "KoPercent": 0.6329113924050633};
    var dataset = [
        {
            "label" : "FAIL",
            "data" : data.KoPercent,
            "color" : "#FF6347"
        },
        {
            "label" : "PASS",
            "data" : data.OkPercent,
            "color" : "#9ACD32"
        }];
    $.plot($("#flot-requests-summary"), dataset, {
        series : {
            pie : {
                show : true,
                radius : 1,
                label : {
                    show : true,
                    radius : 3 / 4,
                    formatter : function(label, series) {
                        return '<div style="font-size:8pt;text-align:center;padding:2px;color:white;">'
                            + label
                            + '<br/>'
                            + Math.round10(series.percent, -2)
                            + '%</div>';
                    },
                    background : {
                        opacity : 0.5,
                        color : '#000'
                    }
                }
            }
        },
        legend : {
            show : true
        }
    });

    // Creates APDEX table
    createTable($("#apdexTable"), {"supportsControllersDiscrimination": true, "overall": {"data": [0.1787974683544304, 500, 1500, "Total"], "isController": false}, "titles": ["Apdex", "T (Toleration threshold)", "F (Frustration threshold)", "Label"], "items": [{"data": [0.08333333333333333, 500, 1500, "Get Settings Page"], "isController": false}, {"data": [0.0, 500, 1500, "Get Settings Page-1"], "isController": false}, {"data": [0.2, 500, 1500, "Get Dashboard Page-1"], "isController": false}, {"data": [1.0, 500, 1500, "Get Settings Page-0"], "isController": false}, {"data": [1.0, 500, 1500, "Get Dashboard Page-0"], "isController": false}, {"data": [0.03365384615384615, 500, 1500, "Post Login Page"], "isController": false}, {"data": [0.2708333333333333, 500, 1500, "Get Post Page"], "isController": false}, {"data": [0.7083333333333334, 500, 1500, "Post Like Post"], "isController": false}, {"data": [0.10833333333333334, 500, 1500, "Get Dashboard Page"], "isController": false}, {"data": [0.375, 500, 1500, "Delete Post"], "isController": false}, {"data": [0.0, 500, 1500, "Get Host Page"], "isController": false}, {"data": [0.045454545454545456, 500, 1500, "Get Login Page"], "isController": false}, {"data": [0.041666666666666664, 500, 1500, "Get Create Post Page"], "isController": false}, {"data": [0.0, 500, 1500, "Get Create Post Page-1"], "isController": false}, {"data": [0.375, 500, 1500, "Post Bio Settings"], "isController": false}, {"data": [1.0, 500, 1500, "Get Create Post Page-0"], "isController": false}, {"data": [0.7083333333333334, 500, 1500, "Post Save Post"], "isController": false}, {"data": [0.3611111111111111, 500, 1500, "Post Create Post Page"], "isController": false}, {"data": [0.0, 500, 1500, "Get Post Page-1"], "isController": false}, {"data": [1.0, 500, 1500, "Get Post Page-0"], "isController": false}]}, function(index, item){
        switch(index){
            case 0:
                item = item.toFixed(3);
                break;
            case 1:
            case 2:
                item = formatDuration(item);
                break;
        }
        return item;
    }, [[0, 0]], 3);

    // Create statistics table
    createTable($("#statisticsTable"), {"supportsControllersDiscrimination": true, "overall": {"data": ["Total", 632, 4, 0.6329113924050633, 2757.8496835443066, 6, 6593, 2779.5, 4576.1, 5043.3, 6245.349999999991, 0.004036506032823321, 0.08323012130712948, 0.0060968288567523395], "isController": false}, "titles": ["Label", "#Samples", "FAIL", "Error %", "Average", "Min", "Max", "Median", "90th pct", "95th pct", "99th pct", "Transactions/s", "Received", "Sent"], "items": [{"data": ["Get Settings Page", 12, 0, 0.0, 2792.5833333333335, 309, 4199, 2830.0, 4072.1000000000004, 4199.0, 4199.0, 7.664852632381537E-5, 2.830656025858351E-4, 3.4298468981456E-4], "isController": false}, {"data": ["Get Settings Page-1", 4, 0, 0.0, 3744.5, 3529, 4131, 3659.0, 4131.0, 4131.0, 4131.0, 0.6837606837606838, 2.604166666666667, 0.5415331196581197], "isController": false}, {"data": ["Get Dashboard Page-1", 20, 0, 0.0, 1875.7999999999997, 778, 2822, 1966.5, 2728.7, 2817.4, 2822.0, 5.85480093676815, 148.57700892857144, 2.149809718969555], "isController": false}, {"data": ["Get Settings Page-0", 4, 0, 0.0, 82.75, 54, 127, 75.0, 127.0, 127.0, 127.0, 1.6333197223356473, 0.2887020212331564, 1.3318573907717437], "isController": false}, {"data": ["Get Dashboard Page-0", 20, 0, 0.0, 21.249999999999996, 6, 109, 14.0, 30.900000000000002, 105.09999999999994, 109.0, 32.89473684210526, 5.814401726973684, 12.20703125], "isController": false}, {"data": ["Post Login Page", 104, 0, 0.0, 3346.250000000001, 1087, 5204, 3780.5, 4665.0, 4752.5, 5190.550000000001, 6.643072941439127E-4, 0.01263794474702648, 3.3539733503164346E-4], "isController": false}, {"data": ["Get Post Page", 24, 0, 0.0, 1569.2916666666667, 680, 3387, 988.0, 3144.0, 3329.0, 3387.0, 1.5329300684009363E-4, 0.004297724386471087, 5.40436441717376E-4], "isController": false}, {"data": ["Post Like Post", 12, 0, 0.0, 480.00000000000006, 13, 981, 659.5, 952.8000000000001, 981.0, 981.0, 7.664661357057675E-5, 0.0013241251395846609, 2.471803387512057E-4], "isController": false}, {"data": ["Get Dashboard Page", 60, 0, 0.0, 3029.633333333333, 793, 5009, 2715.5, 4772.0, 4980.9, 5009.0, 3.83245023247196E-4, 0.012086034764293388, 0.0014904139465265628], "isController": false}, {"data": ["Delete Post", 12, 1, 8.333333333333334, 1049.75, 17, 1840, 1489.0, 1787.8000000000002, 1840.0, 1840.0, 7.664620674952756E-5, 8.877249992512624E-4, 3.1226093768675525E-4], "isController": false}, {"data": ["Get Host Page", 110, 0, 0.0, 3827.4090909090914, 1550, 6593, 3820.0, 5552.0, 6081.049999999991, 6591.35, 7.026476741681694E-4, 0.01889887694927959, 7.959680683936296E-5], "isController": false}, {"data": ["Get Login Page", 110, 0, 0.0, 3146.2454545454543, 124, 4531, 2952.5, 4290.3, 4422.15, 4525.39, 7.026419740647055E-4, 0.017839146525131064, 1.9693188140290082E-4], "isController": false}, {"data": ["Get Create Post Page", 36, 0, 0.0, 3053.027777777778, 720, 4345, 3090.5, 4071.6000000000004, 4313.55, 4345.0, 2.2994456994520994E-4, 0.005905484799562109, 8.568217220427483E-4], "isController": false}, {"data": ["Get Create Post Page-1", 13, 0, 0.0, 3595.3076923076924, 2817, 4042, 3639.0, 4008.0, 4042.0, 4042.0, 2.186343760511268, 55.48274312563068, 0.7280695530608813], "isController": false}, {"data": ["Post Bio Settings", 12, 0, 0.0, 1568.2500000000002, 61, 2874, 1923.0, 2845.8, 2874.0, 2874.0, 7.664762941816498E-5, 5.821614502951461E-4, 3.4475215478043444E-4], "isController": false}, {"data": ["Get Create Post Page-0", 13, 0, 0.0, 84.53846153846155, 29, 153, 80.0, 150.6, 153.0, 153.0, 5.316973415132924, 0.9398165899795502, 1.869248466257669], "isController": false}, {"data": ["Post Save Post", 12, 0, 0.0, 460.5833333333333, 11, 1000, 657.0, 935.2000000000003, 1000.0, 1000.0, 7.664658077016362E-5, 0.0013241245729340343, 2.4718023297200877E-4], "isController": false}, {"data": ["Post Create Post Page", 36, 3, 8.333333333333334, 2778.694444444445, 23, 6313, 3865.5, 5491.6, 6138.75, 6313.0, 2.299380342546354E-4, 2.1507414711192718E-4, 8.850593379049272E-4], "isController": false}, {"data": ["Get Post Page-1", 9, 0, 0.0, 2286.222222222222, 1786, 3364, 1992.0, 3364.0, 3364.0, 3364.0, 1.820756625531054, 46.205255538134736, 0.3890049691482905], "isController": false}, {"data": ["Get Post Page-0", 9, 0, 0.0, 65.33333333333333, 23, 229, 49.0, 229.0, 229.0, 229.0, 2.830188679245283, 0.5002579599056604, 0.6765305621069182], "isController": false}]}, function(index, item){
        switch(index){
            // Errors pct
            case 3:
                item = item.toFixed(2) + '%';
                break;
            // Mean
            case 4:
            // Mean
            case 7:
            // Median
            case 8:
            // Percentile 1
            case 9:
            // Percentile 2
            case 10:
            // Percentile 3
            case 11:
            // Throughput
            case 12:
            // Kbytes/s
            case 13:
            // Sent Kbytes/s
                item = item.toFixed(2);
                break;
        }
        return item;
    }, [[0, 0]], 0, summaryTableHeader);

    // Create error table
    createTable($("#errorsTable"), {"supportsControllersDiscrimination": false, "titles": ["Type of error", "Number of errors", "% in errors", "% in all samples"], "items": [{"data": ["500/Internal Server Error", 4, 100.0, 0.6329113924050633], "isController": false}]}, function(index, item){
        switch(index){
            case 2:
            case 3:
                item = item.toFixed(2) + '%';
                break;
        }
        return item;
    }, [[1, 1]]);

        // Create top5 errors by sampler
    createTable($("#top5ErrorsBySamplerTable"), {"supportsControllersDiscrimination": false, "overall": {"data": ["Total", 632, 4, "500/Internal Server Error", 4, "", "", "", "", "", "", "", ""], "isController": false}, "titles": ["Sample", "#Samples", "#Errors", "Error", "#Errors", "Error", "#Errors", "Error", "#Errors", "Error", "#Errors", "Error", "#Errors"], "items": [{"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": ["Delete Post", 12, 1, "500/Internal Server Error", 1, "", "", "", "", "", "", "", ""], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": ["Post Create Post Page", 36, 3, "500/Internal Server Error", 3, "", "", "", "", "", "", "", ""], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}]}, function(index, item){
        return item;
    }, [[0, 0]], 0);

});
